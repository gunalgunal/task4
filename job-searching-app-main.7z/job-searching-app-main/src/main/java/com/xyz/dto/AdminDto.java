package com.xyz.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AdminDto {
    private Integer id;
    private String name;
    private String email;
    private String password;
    // private String role;
}
